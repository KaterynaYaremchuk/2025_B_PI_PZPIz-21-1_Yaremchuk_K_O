import { useState, useEffect } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'

function CropSelector({ landPlotId }) {
  const [crops, setCrops] = useState([])
  const [selectedCrop, setSelectedCrop] = useState('')

  useEffect(() => {
    const fetchCrops = async () => {
      const response = await axios.get('http://localhost:8000/api/crops', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setCrops(response.data)
    }
    fetchCrops()
  }, [])

  const handleAddCrop = async () => {
    try {
      await axios.post(
        `http://localhost:8000/api/land-plots/${landPlotId}/crops`,
        { crop_id: selectedCrop },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        }
      )
      toast.success('Crop added to land plot')
    } catch (error) {
      toast.error('Error adding crop')
    }
  }

  return (
    <Container>
      <h3>Add Crop to Land Plot</h3>
      <Form>
        <Form.Group>
          <Form.Label>Select Crop</Form.Label>
          <Form.Select
            value={selectedCrop}
            onChange={(e) => setSelectedCrop(e.target.value)}
          >
            <option value=''>Select a crop</option>
            {crops.map((crop) => (
              <option key={crop._id} value={crop._id}>
                {crop.name}
              </option>
            ))}
          </Form.Select>
        </Form.Group>
        <Button onClick={handleAddCrop} className='mt-3'>
          Add Crop
        </Button>
      </Form>
    </Container>
  )
}

export default CropSelector
