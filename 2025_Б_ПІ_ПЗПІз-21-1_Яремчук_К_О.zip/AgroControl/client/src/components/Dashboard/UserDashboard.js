import { useEffect, useState } from 'react'
import { Container, Card, Button } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

function UserDashboard() {
  const [landPlots, setLandPlots] = useState([])
  const navigate = useNavigate()

  useEffect(() => {
    const fetchLandPlots = async () => {
      try {
        const response = await axios.get(
          'http://localhost:8000/api/land-plots',
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('token')}`,
            },
          }
        )
        setLandPlots(response.data)
      } catch (error) {
        console.error('Error fetching land plots:', error)
      }
    }
    fetchLandPlots()
  }, [])

  return (
    <Container>
      <h2>My Land Plots</h2>
      <div className='d-flex flex-wrap'>
        {landPlots.map((plot) => (
          <Card key={plot._id} style={{ width: '18rem', margin: '10px' }}>
            <Card.Body>
              <Card.Title>{plot.name}</Card.Title>
              <Card.Text>Area: {plot.area} ha</Card.Text>
              <Card.Text>Soil: {plot.soil_type}</Card.Text>
              <Button onClick={() => navigate(`/land-plots/${plot._id}`)}>
                View Details
              </Button>
            </Card.Body>
          </Card>
        ))}
      </div>
    </Container>
  )
}

export default UserDashboard
