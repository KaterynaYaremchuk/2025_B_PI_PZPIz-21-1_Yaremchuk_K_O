import { Card, Button } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

function LandPlotCard({ plot }) {
  const navigate = useNavigate()

  return (
    <Card style={{ width: '18rem', margin: '10px' }}>
      <Card.Body>
        <Card.Title>{plot.name}</Card.Title>
        <Card.Text>Area: {plot.area} ha</Card.Text>
        <Card.Text>Soil: {plot.soil_type}</Card.Text>
        <Button onClick={() => navigate(`/land-plots/${plot._id}`)}>
          View Details
        </Button>
      </Card.Body>
    </Card>
  )
}

export default LandPlotCard
