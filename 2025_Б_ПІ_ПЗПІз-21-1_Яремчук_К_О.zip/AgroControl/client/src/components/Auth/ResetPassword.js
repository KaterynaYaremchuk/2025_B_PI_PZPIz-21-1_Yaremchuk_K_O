import { useState } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import { toast } from 'react-toastify'
import axios from 'axios'

function ResetPassword() {
  const [email, setEmail] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await axios.post('http://localhost:8000/api/auth/reset-password', {
        email,
      })
      toast.success('Password reset link sent')
    } catch (error) {
      toast.error('Error sending reset link')
    }
  }

  return (
    <Container>
      <h2>Reset Password</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group>
          <Form.Label>Email</Form.Label>
          <Form.Control
            type='email'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </Form.Group>
        <Button type='submit' className='mt-3'>
          Send Reset Link
        </Button>
      </Form>
    </Container>
  )
}

export default ResetPassword
