import { useState } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import { toast } from 'react-toastify'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { login } from '../../redux/slices/authSlice'
import axios from 'axios'

function LoginForm() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.post(
        'http://localhost:8000/api/auth/login',
        { email, password }
      )
      dispatch(
        login({ token: response.data.access_token, role: response.data.role })
      )
      toast.success('Login successful')
      navigate('/dashboard')
    } catch (error) {
      toast.error('Invalid credentials')
    }
  }

  return (
    <Container>
      <h2>Login</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group>
          <Form.Label>Email</Form.Label>
          <Form.Control
            type='email'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Password</Form.Label>
          <Form.Control
            type='password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </Form.Group>
        <Button type='submit' className='mt-3'>
          Login
        </Button>
      </Form>
    </Container>
  )
}

export default LoginForm
