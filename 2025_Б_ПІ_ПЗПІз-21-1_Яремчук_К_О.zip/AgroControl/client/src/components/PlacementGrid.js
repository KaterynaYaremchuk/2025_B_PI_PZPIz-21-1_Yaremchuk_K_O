import { useEffect, useState } from 'react'
import axios from 'axios'
import { Container } from 'react-bootstrap'

function PlacementGrid({ landPlotId }) {
  const [grid, setGrid] = useState([])

  useEffect(() => {
    const fetchPlacement = async () => {
      const response = await axios.get(
        `http://localhost:8000/api/land-plots/${landPlotId}/placement`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        }
      )
      setGrid(response.data)
    }
    fetchPlacement()
  }, [landPlotId])

  return (
    <Container>
      <h3>Placement Grid</h3>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(10, 50px)',
          gap: '5px',
        }}
      >
        {grid.map((cell, index) => (
          <div
            key={index}
            style={{
              width: '50px',
              height: '50px',
              border: '1px solid black',
              background: cell ? 'green' : 'white',
              textAlign: 'center',
            }}
          >
            {cell ? cell.crop_id : ''}
          </div>
        ))}
      </div>
    </Container>
  )
}

export default PlacementGrid
