import { ListGroup } from 'react-bootstrap'

function TaskItem({ task }) {
  return (
    <ListGroup.Item>
      {task.task} for Crop ID: {task.crop_id} - {task.status}
    </ListGroup.Item>
  )
}

export default TaskItem
