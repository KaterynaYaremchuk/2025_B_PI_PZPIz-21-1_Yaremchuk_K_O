import { useEffect, useState } from 'react'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import axios from 'axios'
import { Container } from 'react-bootstrap'

function CareCalendar() {
  const [tasks, setTasks] = useState([])
  const [date, setDate] = useState(new Date())

  useEffect(() => {
    const fetchTasks = async () => {
      const response = await axios.get('http://localhost:8000/api/calendar', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setTasks(response.data)
    }
    fetchTasks()
  }, [])

  const onChange = (newDate) => {
    setDate(newDate)
  }

  return (
    <Container>
      <h2>Agri Calendar</h2>
      <Calendar onChange={onChange} value={date} />
      <h3>Tasks for {date.toDateString()}</h3>
      <ul>
        {tasks
          .filter(
            (task) => new Date(task.date).toDateString() === date.toDateString()
          )
          .map((task) => (
            <li key={task._id}>
              {task.task} for Crop ID: {task.crop_id} - {task.status}
            </li>
          ))}
      </ul>
    </Container>
  )
}

export default CareCalendar
