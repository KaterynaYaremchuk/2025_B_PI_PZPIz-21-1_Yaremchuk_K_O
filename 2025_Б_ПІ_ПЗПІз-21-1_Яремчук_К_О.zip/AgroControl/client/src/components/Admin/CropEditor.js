import { useState } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'

function CropEditor() {
  const [name, setName] = useState('')
  const [vegetationPeriod, setVegetationPeriod] = useState('')
  const [soilType, setSoilType] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await axios.post(
        'http://localhost:8000/api/crops',
        {
          name,
          vegetation_period: parseInt(vegetationPeriod),
          soil_type: soilType,
        },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        }
      )
      toast.success('Crop added')
    } catch (error) {
      toast.error('Error adding crop')
    }
  }

  return (
    <Container>
      <h2>Add New Crop</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group>
          <Form.Label>Crop Name</Form.Label>
          <Form.Control
            type='text'
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Vegetation Period (days)</Form.Label>
          <Form.Control
            type='number'
            value={vegetationPeriod}
            onChange={(e) => setVegetationPeriod(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Soil Type</Form.Label>
          <Form.Control
            type='text'
            value={soilType}
            onChange={(e) => setSoilType(e.target.value)}
            required
          />
        </Form.Group>
        <Button type='submit' className='mt-3'>
          Add Crop
        </Button>
      </Form>
    </Container>
  )
}

export default CropEditor
