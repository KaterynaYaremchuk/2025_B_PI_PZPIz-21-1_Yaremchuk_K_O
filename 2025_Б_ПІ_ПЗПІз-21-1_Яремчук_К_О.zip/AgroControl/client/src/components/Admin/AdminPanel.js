import { useEffect, useState } from 'react'
import { Container, Table, Button } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'

function AdminPanel() {
  const [users, setUsers] = useState([])

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await axios.get('http://localhost:8000/api/auth/users', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setUsers(response.data)
    }
    fetchUsers()
  }, [])

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`http://localhost:8000/api/auth/users/${userId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setUsers(users.filter((user) => user._id !== userId))
      toast.success('User deleted')
    } catch (error) {
      toast.error('Error deleting user')
    }
  }

  return (
    <Container>
      <h2>Admin Panel</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>
                <Button
                  variant='danger'
                  onClick={() => handleDeleteUser(user._id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  )
}

export default AdminPanel
