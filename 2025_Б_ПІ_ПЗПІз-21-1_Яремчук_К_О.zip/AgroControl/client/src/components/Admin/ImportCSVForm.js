import { useState } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'

function ImportCSVForm() {
  const [file, setFile] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    const formData = new FormData()
    formData.append('file', file)
    try {
      await axios.post('http://localhost:8000/api/crops/import', formData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      toast.success('Crops imported successfully')
    } catch (error) {
      toast.error('Error importing crops')
    }
  }

  return (
    <Container>
      <h2>Import Crops from CSV</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group>
          <Form.Label>Upload CSV</Form.Label>
          <Form.Control
            type='file'
            accept='.csv'
            onChange={(e) => setFile(e.target.files[0])}
          />
        </Form.Group>
        <Button type='submit' className='mt-3'>
          Import
        </Button>
      </Form>
    </Container>
  )
}

export default ImportCSVForm
