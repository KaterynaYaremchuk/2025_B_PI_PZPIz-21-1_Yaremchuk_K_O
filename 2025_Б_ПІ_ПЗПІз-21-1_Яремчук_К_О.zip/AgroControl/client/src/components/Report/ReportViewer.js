import { useEffect, useState } from 'react'
import { Container, Table } from 'react-bootstrap'
import axios from 'axios'

function ReportViewer() {
  const [reports, setReports] = useState([])

  useEffect(() => {
    const fetchReports = async () => {
      const response = await axios.get(
        'http://localhost:8000/api/reports/list',
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        }
      )
      setReports(response.data)
    }
    fetchReports()
  }, [])

  return (
    <Container>
      <h2>View Reports</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Type</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((report) => (
            <tr key={report._id}>
              <td>{report.type}</td>
              <td>{new Date(report.created_at).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  )
}

export default ReportViewer
