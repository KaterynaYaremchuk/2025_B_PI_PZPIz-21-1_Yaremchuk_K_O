import { useState } from 'react'
import { Form, Button, Container } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'

function ReportGenerator() {
  const [reportType, setReportType] = useState('pdf')

  const handleGenerate = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8000/api/reports?type=${reportType}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
          responseType: 'blob',
        }
      )
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `report.${reportType}`)
      document.body.appendChild(link)
      link.click()
      toast.success('Report generated')
    } catch (error) {
      toast.error('Error generating report')
    }
  }

  return (
    <Container>
      <h2>Generate Report</h2>
      <Form>
        <Form.Group>
          <Form.Label>Report Type</Form.Label>
          <Form.Select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
          >
            <option value='pdf'>PDF</option>
            <option value='csv'>CSV</option>
          </Form.Select>
        </Form.Group>
        <Button onClick={handleGenerate} className='mt-3'>
          Generate
        </Button>
      </Form>
    </Container>
  )
}

export default ReportGenerator
