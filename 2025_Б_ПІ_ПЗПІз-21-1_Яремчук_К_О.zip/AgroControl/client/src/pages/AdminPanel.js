import AdminPanel from '../components/Admin/AdminPanel'
import ImportCSVForm from '../components/Admin/ImportCSVForm'
import CropEditor from '../components/Admin/CropEditor'
import { Container } from 'react-bootstrap'

function Admin() {
  return (
    <Container>
      <AdminPanel />
      <ImportCSVForm />
      <CropEditor />
    </Container>
  )
}

export default Admin
