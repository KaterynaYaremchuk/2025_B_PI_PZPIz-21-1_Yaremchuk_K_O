import UserDashboard from '../components/Dashboard/UserDashboard'

function Dashboard() {
  return <UserDashboard />
}

export default Dashboard
