import { useState } from 'react'
import { Container, Form, Button } from 'react-bootstrap'
import axios from 'axios'
import { toast } from 'react-toastify'
import UserDashboard from '../components/Dashboard/UserDashboard'

function LandPlots() {
  const [name, setName] = useState('')
  const [area, setArea] = useState('')
  const [soilType, setSoilType] = useState('')

  const handleAddPlot = async (e) => {
    e.preventDefault()
    try {
      await axios.post(
        'http://localhost:8000/api/land-plots',
        { name, area: parseFloat(area), soil_type: soilType },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        }
      )
      toast.success('Land plot added')
      setName('')
      setArea('')
      setSoilType('')
    } catch (error) {
      toast.error('Error adding land plot')
    }
  }

  return (
    <Container>
      <h2>Manage Land Plots</h2>
      <Form onSubmit={handleAddPlot}>
        <Form.Group>
          <Form.Label>Name</Form.Label>
          <Form.Control
            type='text'
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Area (ha)</Form.Label>
          <Form.Control
            type='number'
            value={area}
            onChange={(e) => setArea(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Soil Type</Form.Label>
          <Form.Control
            type='text'
            value={soilType}
            onChange={(e) => setSoilType(e.target.value)}
            required
          />
        </Form.Group>
        <Button type='submit' className='mt-3'>
          Add Land Plot
        </Button>
      </Form>
      <UserDashboard />
    </Container>
  )
}

export default LandPlots
