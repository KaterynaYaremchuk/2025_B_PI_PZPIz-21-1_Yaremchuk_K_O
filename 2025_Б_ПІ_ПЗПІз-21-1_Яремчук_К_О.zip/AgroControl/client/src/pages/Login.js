import LoginForm from '../components/Auth/LoginForm'

function Login() {
  return <LoginForm />
}

export default Login
