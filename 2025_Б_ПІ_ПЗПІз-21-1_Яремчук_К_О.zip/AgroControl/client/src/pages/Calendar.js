import CareCalendar from '../components/Calendar/CareCalendar'

function Calendar() {
  return <CareCalendar />
}

export default Calendar
