import { useEffect, useState } from 'react'
import { Container, Table, Button } from 'react-bootstrap'
import axios from 'axios'
import CropSelector from '../components/Dashboard/CropSelector'

function Crops() {
  const [crops, setCrops] = useState([])

  useEffect(() => {
    const fetchCrops = async () => {
      const response = await axios.get('http://localhost:8000/api/crops', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      })
      setCrops(response.data)
    }
    fetchCrops()
  }, [])

  return (
    <Container>
      <h2>Manage Crops</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Name</th>
            <th>Vegetation Period</th>
            <th>Soil Type</th>
          </tr>
        </thead>
        <tbody>
          {crops.map((crop) => (
            <tr key={crop._id}>
              <td>{crop.name}</td>
              <td>{crop.vegetation_period} days</td>
              <td>{crop.soil_type}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <CropSelector landPlotId='example_plot_id' />
    </Container>
  )
}

export default Crops
