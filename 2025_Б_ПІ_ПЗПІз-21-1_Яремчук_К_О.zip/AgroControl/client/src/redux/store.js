import { configureStore } from '@reduxjs/toolkit'
import authReducer from './slices/authSlice'
import landPlotReducer from './slices/landPlotSlice'
import cropReducer from './slices/cropSlice'

export default configureStore({
  reducer: {
    auth: authReducer,
    landPlots: landPlotReducer,
    crops: cropReducer,
  },
})
