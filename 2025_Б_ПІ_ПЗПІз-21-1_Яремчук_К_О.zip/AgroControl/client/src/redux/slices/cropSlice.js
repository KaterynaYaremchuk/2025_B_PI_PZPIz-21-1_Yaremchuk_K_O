import { createSlice } from '@reduxjs/toolkit'

const cropSlice = createSlice({
  name: 'crops',
  initialState: {
    crops: [],
  },
  reducers: {
    setCrops(state, action) {
      state.crops = action.payload
    },
  },
})

export const { setCrops } = cropSlice.actions
export default cropSlice.reducer
