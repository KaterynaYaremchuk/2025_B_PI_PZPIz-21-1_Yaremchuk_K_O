import { createSlice } from '@reduxjs/toolkit'

const landPlotSlice = createSlice({
  name: 'landPlots',
  initialState: {
    plots: [],
  },
  reducers: {
    setPlots(state, action) {
      state.plots = action.payload
    },
  },
})

export const { setPlots } = landPlotSlice.actions
export default landPlotSlice.reducer
