from pydantic import BaseModel, EmailStr
from typing import Optional

class UserSchema(BaseModel):
    _id: str
    email: EmailStr
    password: str
    role: str
    name: Optional[str] = None
    phone: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True