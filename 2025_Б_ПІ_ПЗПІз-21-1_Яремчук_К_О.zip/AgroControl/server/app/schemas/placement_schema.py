from pydantic import BaseModel

class PlacementSchema(BaseModel):
    _id: str
    land_plot_id: str
    crop_id: str
    x: int
    y: int

    class Config:
        arbitrary_types_allowed = True