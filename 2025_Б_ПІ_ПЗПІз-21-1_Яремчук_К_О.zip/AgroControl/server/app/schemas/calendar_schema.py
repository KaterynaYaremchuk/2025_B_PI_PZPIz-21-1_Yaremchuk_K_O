from pydantic import BaseModel

class CalendarTaskSchema(BaseModel):
    _id: str
    crop_id: str
    date: str
    task: str
    status: str

    class Config:
        arbitrary_types_allowed = True