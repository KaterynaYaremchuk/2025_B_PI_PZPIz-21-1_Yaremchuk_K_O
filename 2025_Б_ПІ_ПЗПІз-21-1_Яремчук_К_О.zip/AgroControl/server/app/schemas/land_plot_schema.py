from pydantic import BaseModel
from typing import Optional

class LandPlotSchema(BaseModel):
    _id: str
    user_id: str
    name: str
    area: float
    soil_type: str
    water_source: Optional[str] = None
    light_level: Optional[str] = None
    coordinates: Optional[dict] = None

    class Config:
        arbitrary_types_allowed = True