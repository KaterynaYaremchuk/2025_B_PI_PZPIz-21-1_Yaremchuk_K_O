from io import BytesIO
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from app.db import get_db

def generate_report(report_type: str, user_id: str):
    db = get_db()
    plots = list(db.land_plots.find({"user_id": user_id}))
    if report_type == "pdf":
        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=letter)
        c.drawString(100, 750, "Land Plots Report")
        y = 700
        for plot in plots:
            c.drawString(100, y, f"Name: {plot['name']}, Area: {plot['area']} ha, Soil: {plot['soil_type']}")
            y -= 20
        c.save()
        buffer.seek(0)
        return buffer
    else:
        df = pd.DataFrame(plots)
        return df.to_csv(index=False).encode()