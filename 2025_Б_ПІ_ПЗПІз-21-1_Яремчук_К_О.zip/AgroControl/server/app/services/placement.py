from fastapi import HTTPException
from app.db import get_db

async def optimize_placement(land_plot_id: str, crops: list):
    db = get_db()
    land_plot = db.land_plots.find_one({"_id": land_plot_id})
    if not land_plot:
        raise HTTPException(status_code=404, detail="Land plot not found")

    grid = [[None for _ in range(10)] for _ in range(10)]
    placement = []

    for crop_id in crops:
        crop = db.crops.find_one({"_id": crop_id})
        if not crop:
            continue
        for i in range(10):
            for j in range(10):
                if grid[i][j] is None and crop["soil_type"] == land_plot["soil_type"]:
                    grid[i][j] = crop_id
                    placement.append({"land_plot_id": land_plot_id, "crop_id": crop_id, "x": i, "y": j})
                    break
            else:
                continue
            break

    db.placements.insert_many(placement)
    return placement