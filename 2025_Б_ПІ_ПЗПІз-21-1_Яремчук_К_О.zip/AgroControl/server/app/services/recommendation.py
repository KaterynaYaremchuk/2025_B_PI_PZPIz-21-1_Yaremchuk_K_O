from sklearn.neighbors import NearestNeighbors
import numpy as np
from app.db import get_db

async def recommend_crops(soil_type: str, temperature: float, light_level: str):
    db = get_db()
    crops = list(db.crops.find())
    
    features = []
    crop_ids = []
    for crop in crops:
        feature = [
            1 if crop["soil_type"] == soil_type else 0,
            (temperature - crop["temperature_range"]["min"]) / (crop["temperature_range"]["max"] - crop["temperature_range"]["min"]),
            1 if crop["light_needs"] == light_level else 0
        ]
        features.append(feature)
        crop_ids.append(crop["_id"])
    
    X = np.array(features)
    knn = NearestNeighbors(n_neighbors=5).fit(X)
    query = np.array([[1 if soil_type == soil_type else 0, temperature / 30, 1 if light_level == light_level else 0]])
    distances, indices = knn.kneighbors(query)
    
    recommended = [crops[i] for i in indices[0]]
    return recommended