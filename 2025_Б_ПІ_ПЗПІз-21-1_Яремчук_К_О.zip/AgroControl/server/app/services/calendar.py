from fastapi import HTTPException
from datetime import datetime, timedelta
from app.db import get_db

async def generate_calendar(crop_id: str, planting_date: datetime):
    db = get_db()
    crop = db.crops.find_one({"_id": crop_id})
    if not crop:
        raise HTTPException(status_code=404, detail="Crop not found")

    calendar = []
    current_date = planting_date
    vegetation_days = crop["vegetation_period"]
    end_date = planting_date + timedelta(days=vegetation_days)

    while current_date <= end_date:
        if (current_date - planting_date).days % crop["watering_frequency"] == 0:
            calendar.append({
                "date": current_date.isoformat(),
                "task": "Watering",
                "crop_id": crop_id,
                "status": "pending",
                "user_id": crop["user_id"]
            })
        if (current_date - planting_date).days % crop["fertilizer_frequency"] == 0:
            calendar.append({
                "date": current_date.isoformat(),
                "task": "Fertilizing",
                "crop_id": crop_id,
                "status": "pending",
                "user_id": crop["user_id"]
            })
        current_date += timedelta(days=1)

    db.calendar.insert_many(calendar)
    return calendar