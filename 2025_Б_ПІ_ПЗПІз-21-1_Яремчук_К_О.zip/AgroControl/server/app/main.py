from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import auth, land_plots, crops, calendar, reports
from app.db import init_db

app = FastAPI(title="Agri Management System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(land_plots.router, prefix="/api/land-plots", tags=["land-plots"])
app.include_router(crops.router, prefix="/api/crops", tags=["crops"])
app.include_router(calendar.router, prefix="/api/calendar", tags=["calendar"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])

@app.get("/")
async def root():
    return {"message": "Agri Management System API"}