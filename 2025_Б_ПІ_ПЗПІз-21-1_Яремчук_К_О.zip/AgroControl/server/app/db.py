from pymongo import MongoClient

client = None
db = None

def init_db():
    global client, db
    client = MongoClient("mongodb://mongodb:27017/")
    db = client["agri_management"]

def get_db():
    return db