from fastapi import APIRouter, Depends
from app.db import get_db
from app.services.calendar import generate_calendar
from app.services.auth import get_current_user
from datetime import datetime

router = APIRouter()

@router.get("/")
async def get_calendar(current_user: dict = Depends(get_current_user)):
    db = get_db()
    tasks = list(db.calendar.find({"user_id": current_user["sub"]}))
    return tasks

@router.post("/{crop_id}")
async def create_calendar(crop_id: str, planting_date: str, current_user: dict = Depends(get_current_user)):
    planting_date = datetime.fromisoformat(planting_date)
    return await generate_calendar(crop_id, planting_date)