from fastapi import APIRouter, Depends, HTTPException
from app.models.crop import Crop
from app.db import get_db
from app.services.auth import get_current_user
import pandas as pd
from fastapi import UploadFile

router = APIRouter()

@router.post("/")
async def create_crop(crop: Crop, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    db = get_db()
    db.crops.insert_one(crop.dict())
    return {"message": "Crop created"}

@router.get("/")
async def get_crops():
    db = get_db()
    crops = list(db.crops.find())
    return crops

@router.post("/import")
async def import_crops(file: UploadFile, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    df = pd.read_csv(file.file)
    db = get_db()
    crops = df.to_dict('records')
    db.crops.insert_many(crops)
    return {"message": "Crops imported"}