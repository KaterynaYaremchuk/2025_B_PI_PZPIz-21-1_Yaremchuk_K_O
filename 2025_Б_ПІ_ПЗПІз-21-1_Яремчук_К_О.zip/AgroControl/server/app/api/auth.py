from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from app.models.user import User
from app.services.auth import create_user, authenticate_user, get_current_user
from jose import jwt

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")

@router.post("/register")
async def register(user: User):
    return await create_user(user)

@router.post("/login")
async def login(email: str, password: str):
    return await authenticate_user(email, password)

@router.get("/users")
async def get_users(current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    from app.db import get_db
    db = get_db()
    users = list(db.users.find({}, {"password": 0}))
    return users

@router.delete("/users/{user_id}")
async def delete_user(user_id: str, current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    from app.db import get_db
    db = get_db()
    db.users.delete_one({"_id": user_id})
    return {"message": "User deleted"}