from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from app.db import get_db
from app.services.reports import generate_report
from app.services.auth import get_current_user

router = APIRouter()

@router.get("/")
async def get_report(report_type: str, current_user: dict = Depends(get_current_user)):
    report_data = generate_report(report_type, current_user["sub"])
    return StreamingResponse(
        report_data,
        media_type="application/pdf" if report_type == "pdf" else "text/csv"
    )

@router.get("/list")
async def list_reports(current_user: dict = Depends(get_current_user)):
    db = get_db()
    reports = list(db.reports.find({"user_id": current_user["sub"]}))
    return reports