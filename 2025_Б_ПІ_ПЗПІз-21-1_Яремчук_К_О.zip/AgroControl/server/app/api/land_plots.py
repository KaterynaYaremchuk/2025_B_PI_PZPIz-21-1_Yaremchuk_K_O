from fastapi import APIRouter, Depends, HTTPException
from app.models.land_plot import LandPlot
from app.db import get_db
from app.services.auth import get_current_user

router = APIRouter()

@router.post("/")
async def create_land_plot(plot: LandPlot, current_user: dict = Depends(get_current_user)):
    db = get_db()
    plot_dict = plot.dict()
    plot_dict["user_id"] = current_user["sub"]
    db.land_plots.insert_one(plot_dict)
    return {"message": "Land plot created"}

@router.get("/")
async def get_land_plots(current_user: dict = Depends(get_current_user)):
    db = get_db()
    plots = list(db.land_plots.find({"user_id": current_user["sub"]}))
    return plots

@router.get("/{plot_id}/placement")
async def get_placement(plot_id: str, current_user: dict = Depends(get_current_user)):
    db = get_db()
    placements = list(db.placements.find({"land_plot_id": plot_id}))
    return placements