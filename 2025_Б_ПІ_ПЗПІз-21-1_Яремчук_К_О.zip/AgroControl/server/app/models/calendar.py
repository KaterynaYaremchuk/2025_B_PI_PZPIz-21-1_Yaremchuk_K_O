from pydantic import BaseModel

class CalendarTask(BaseModel):
    crop_id: str
    date: str
    task: str
    status: str