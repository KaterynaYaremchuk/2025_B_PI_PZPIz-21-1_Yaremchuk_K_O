from pydantic import BaseModel
from typing import Optional

class Crop(BaseModel):
    name: str
    vegetation_period: int
    watering_frequency: int
    fertilizer_frequency: int
    soil_type: str
    light_needs: str
    temperature_range: dict