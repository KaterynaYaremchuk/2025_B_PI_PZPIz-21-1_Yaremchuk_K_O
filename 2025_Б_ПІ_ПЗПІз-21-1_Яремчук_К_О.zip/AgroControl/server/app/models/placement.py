from pydantic import BaseModel

class Placement(BaseModel):
    land_plot_id: str
    crop_id: str
    x: int
    y: int